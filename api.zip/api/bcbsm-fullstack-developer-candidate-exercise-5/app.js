const express = require('express');
app = express();
const bodyParse = require('body-parser')
const { initializeDB } = require('./db');
const cors = require('cors');
const multer = require('multer');
const nodemailer = require('nodemailer');
let db;
app.use(bodyParse.json());
app.use(cors({
  origin: 'http://localhost:4200',
}));
async function sendMail(req) {
  try {
    const transporter = nodemailer.createTransport({
      host: 'smtp.gmail.com',
      port: 587,
      secure: false,
      auth: {
        user: 'helpall678@gmail.com',
        pass: 'szoi pcyz evqj ajbp',
      }
    });
    const mailOptions = {
      from: req.body.from,
      to: req.body.to,
      subject: 'From My Node App',
      text: req.body.body,
      attachments: req?.file ? [
        {
          filename: req?.file?.originalname,
          path: req?.file?.path,
          file: req?.file?.buffer,
        },
      ] : [],
    };
    const result = await transporter.sendMail(mailOptions);
    return result;
  } catch (err) {
    return err
  }
}


initializeDB()
  .then((database) => {
    db = database;
    const storage = multer.memoryStorage();
    const upload = multer({ storage });

    app.listen(3000, async (err) => {
      if (err) {
        console.error("something isn't right")
      } else {
        console.log('Server is running ');
      }
    });

    app.post('/login', async (req, res) => {
      try {
        const collection = db.collection('users');
        const { username, password } = req.body;
        const users = await collection.findOne({ username, password });
        if (users) {
          res.status(200).json({ err: null, data: { message: 'Login successful', uid: users._id } });
        } else {
          res.status(404).json({ err: 'none found', data: { message: 'invalid credentials' } });
        }
      } catch (err) {
        console.error('Error fetching users:', err);
        res.status(500).json({ err: err.message });
      }
    })
    app.post('/check', async (req, res) => {
      try {
        const collection = db.collection('users');
        const { id } = req.body;
        const user = await collection.findOne({ id });
        if (user) {
          res.status(200).json({ err: null, data: { message: 'valid user' } });
        } else {
          res.status(401).json({ err: 'unauthorized', data: { message: 'Unauthorized user' } });
        }

      } catch (e) {
        res.status(500).json({ err: err.message });
      }
    })
    app.post('/sendMail', upload.single('attachment'), async (req, res) => {
      try {
        await sendMail(req).then((res) => { })
        const emailCollection = db.collection('emails');
        const usersCollection = db.collection('users');
        const { id } = req.body.uploadUser;
        const user = await usersCollection.findOne({ id });

        const emailDocument = {
          from: req.body.from,
          to: req.body.to,
          attachmentFileName: req?.file?.originalname,
          attachmentFileData: req?.file?.buffer,
          uploadUser: user.username,
          uploadDate: new Date(),
        };
        await emailCollection.insertOne(emailDocument);

        res.status(201).json({ err: null, data: { message: 'Email sent successfully.' } });

      } catch (err) {
        console.error('Something went wrong:', err);
        res.status(500).json({ err: err.message });
      }
    })
    app.get('/getMails', async (req, res) => {
      try {
        const emailCollection = db.collection('emails');
        const mails = await emailCollection.find().toArray();
        res.status(200).json({ err: null, data: { mails, message: 'List successfull' } });
      } catch (err) {
        console.error('Something went wrong:', err);
        res.status(500).json({ err: err.message });
      }
    })
  })
  .catch((err) => {
    console.error('Failed to initialize MongoDB:', err);
    process.exit(1);
  });
