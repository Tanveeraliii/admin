const { MongoClient } = require('mongodb');
const url = 'mongodb://127.0.0.1:27017';
const dbName = 'demo';
const client = new MongoClient(url);
const {encrypt} = require('../crypto')
let db;

async function initializeDB() {
  try {
    if (!db) {
      await client.connect();
      // const adminDb = client.db('demo');
      // await adminDb.command({ listDatabases: 1 });  
      db = client.db(dbName);
      const users = db.collection('users');
      const count = await users.countDocuments();
      if (count === 0) {
        await users.insertOne({ username: 'admin', password: 'passwordforAdmin' });
      }
    }
    return db;
  } catch (err) {
    console.error('Error connecting to MongoDB:', err);
    throw err;
  }
}
  

module.exports = {
  initializeDB,
};
