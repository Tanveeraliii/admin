const crypto = require('crypto');


// Encryption and decryption functions
const algorithm = 'aes-256-cbc';
const encryptionKey = 'thisissecret'; 
const iv = crypto.randomBytes(32);

function encrypt(text) {
  const cipher = crypto.createCipheriv(algorithm, Buffer.from(encryptionKey), iv.toString('hex'));
  let encrypted = cipher.update(text, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  return { iv: iv.toString('hex'), encryptedData: encrypted };
}

function decrypt(text) {
  const decipher = crypto.createDecipheriv(
    algorithm,
    Buffer.from(encryptionKey),
    Buffer.from(text.iv, 'hex')
  );
  let decrypted = decipher.update(text.encryptedData, 'hex', 'utf8');
  decrypted += decipher.final('utf8');
  return decrypted;
}

module.exports = {
    encrypt,
  decrypt,
};





